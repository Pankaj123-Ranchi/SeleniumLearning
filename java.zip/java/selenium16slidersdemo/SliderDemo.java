package selenium16slidersdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SliderDemo {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/");
		driver.manage().window().maximize();
		
		Actions act = new Actions(driver);
		
		//Min Slider
		WebElement min_slider = driver.findElement(By.xpath("//div[@class='price-range-block']//span[1]"));
		System.out.println("Default Location of the min slider:"+min_slider.getLocation());//(59, 249)=(x,y)
		System.out.println("Location of the x coordinate min slider:"+min_slider.getLocation().getX());//59
		System.out.println("Location of the y coordinate min slider:"+min_slider.getLocation().getY());//249
		act.dragAndDropBy(min_slider, 100, 0).perform();
		System.out.println("Location of the min slider after moving:"+min_slider.getLocation());//(158, 249)=(x,y)
		
		//Max Slider
		WebElement max_slider = driver.findElement(By.xpath("//span[2]"));
		System.out.println("Default Location of the max slider:"+max_slider.getLocation());//(510, 249)=(x,y)
		System.out.println("Location of the x coordinate max slider:"+max_slider.getLocation().getX());//510
		System.out.println("Location of the y coordinate max slider:"+max_slider.getLocation().getY());//249
		act.dragAndDropBy(max_slider, -60, 0).perform();
		System.out.println("Location of the max slider after moving:"+max_slider.getLocation());//(451, 249)=(x,y)
		
		
		
		
	}

}
package day21;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstTestCase {

	public static void main(String[] args) {
		
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://google.com");
		//driver.get("https://empower--uat.sandbox.my.salesforce.com/");
		driver.findElement(By.xpath("//textarea[@title='Search']")).sendKeys("test");
		
		
		
	}

}

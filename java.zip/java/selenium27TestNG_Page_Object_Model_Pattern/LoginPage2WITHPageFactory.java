package selenium27TestNG_Page_Object_Model_Pattern;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage2WITHPageFactory {

	WebDriver driver;

	// Constructors
	LoginPage2WITHPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);//MANDATORY
		
	}

	// Locators

	/*By txt_username_loc = By.xpath("//input[@placeholder='Username']");
	By txt_password_loc = By.xpath("//input[@placeholder='Password']");
	By btn_login_loc = By.xpath("//button[normalize-space()='Login']");*/
	
	
	@FindBy(xpath="//input[@placeholder='username']") 
	WebElement txt_username;

	@FindBy(xpath="//input[@placeholder='password']") 
	WebElement txt_password;
	
	@FindBy(xpath="//button[normalize-space()='Login']") 
	WebElement btn_login;
	
	@FindBy(tagName = "a")
	List<WebElement> links;
	
	// Action Methods

	/*public void setUserName(String user) {
		driver.findElement(txt_username_loc).sendKeys(user);
	}

	public void setPassword(String pwd) {
		driver.findElement(txt_password_loc).sendKeys(pwd);
	}

	public void clickLogin() {
		driver.findElement(btn_login_loc).click();
	}*/
	
	public void setUserName(String user) 
	{
		txt_username.sendKeys(user);
	}
	public void setPassword(String pwd)
	{
		txt_password.sendKeys(pwd);
	}
	public void clickLogin() 
	{
		btn_login.click();
	}
	
	
}

package selenium17JavascriptExecutorDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FileUpload {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://davidwalsh.name/demo/multiple-file-upload.php");
		driver.manage().window().maximize();
		
		//1.)Single File Upload-- Test1.txt
		/*driver.findElement(By.xpath("//input[@id='filesToUpload']")).sendKeys("C:\\Users\\E026535\\Test1.txt");
		
		if(driver.findElement(By.xpath("//ul[@id='fileList']//li")).getText().equals("Test1.txt"))
				{
			
		System.out.println("File is successfully uploaded");
				
				}
		else
		{
			System.out.println("Upload Failed");
		}
        */
	
      //2.)Multiple Files Upload
		String file1 = "C:\\\\Users\\\\E026535\\\\Test1.txt";
		String file2 = "C:\\\\Users\\\\E026535\\\\Test2.txt";
		driver.findElement(By.xpath("//input[@id='filesToUpload']")).sendKeys(file1+"\n"+file2);
		
		int noOfFilesUploaded = driver.findElements(By.xpath("//ul[@id='fileList']//li")).size();
		
		//Validation 1--Number Of Files
		if (noOfFilesUploaded==2)
			
		{
			System.out.println("All Files are Uploaded");
		}
		else 
		{
			System.out.println("Files are not uploaded or incorrect files uploaded");
		}
		
		//Validate File Names
		
		if(driver.findElement(By.xpath("//ul[@id='fileList']//li[1]")).getText().equals("Test1.txt")
				&& driver.findElement(By.xpath("//ul[@id='fileList']//li[2]")).getText().equals("Test2.txt"))
		{
			System.out.println("File names matching....");
		}
		else 
		{
			System.out.println("File names are not matching....");
		}
	}
}

